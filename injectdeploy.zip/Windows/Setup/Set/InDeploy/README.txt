C:\Windows\Setup\Set\InDeploy\*.exe：部署中以 /S 参数执行 *.exe
C:\Windows\Setup\Set\InDeploy\*.msi：部署中以 /passive /qb-! /norestart 参数执行 *.msi
C:\Windows\Setup\Set\InDeploy\*.reg：部署中以 regedit /s 方式导入注册表