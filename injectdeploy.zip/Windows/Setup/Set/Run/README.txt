C:\Windows\Setup\Set\Run\*.exe：进桌面OSC执行前以 /S 参数执行 *.exe
C:\Windows\Setup\Set\Run\*.msi：进桌面OSC执行前以 /passive /qb-! /norestart 参数执行 *.msi
C:\Windows\Setup\Set\Run\*.reg：进桌面OSC执行前以 regedit /s 方式导入注册表